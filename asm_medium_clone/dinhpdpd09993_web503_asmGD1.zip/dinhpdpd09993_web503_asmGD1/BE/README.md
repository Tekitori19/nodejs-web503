POST /api/register - Đăng ký tài khoản
POST /api/login - Đăng nhập
POST /api/posts - Đăng bài viết (yêu cầu auth)
PUT /api/posts/:id - Cập nhật bài viết (yêu cầu auth)
GET /api/posts - Lấy danh sách bài viết
GET /api/posts/:id - Xem chi tiết bài viết
GET /api/posts/search - Tìm kiếm bài viết
GET /api/users/:id - Xem thông tin cá nhân
PUT /api/users/profile - Cập nhật thông tin cá nhân (yêu cầu auth)
