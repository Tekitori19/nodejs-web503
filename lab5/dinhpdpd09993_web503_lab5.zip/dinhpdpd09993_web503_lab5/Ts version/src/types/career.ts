export interface career {
    title: String,
    desc: String,
}
