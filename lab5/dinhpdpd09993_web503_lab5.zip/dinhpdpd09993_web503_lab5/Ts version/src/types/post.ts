export interface product {
    id: number,
    imgPath: String,
    title: String,
    desc: String,
}
