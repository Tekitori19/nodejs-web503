import { feature } from '../models/feature.js';

export const getFeatures = (): feature[] => {
    return [
        { title: 'Feature 1', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
        { title: 'Feature 2', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
        { title: 'Feature 3', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
    ]
}
