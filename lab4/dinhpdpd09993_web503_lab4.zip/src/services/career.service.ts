import { career } from '../models/career.js';

export const getCareers = (): career[] => {
    return [
        { title: 'Career 1', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
        { title: 'Career 2', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
        { title: 'Career 3', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
        { title: 'Career 4', desc: 'when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries' },
    ]
}
